"""All game tunables in one place: timings, speeds, ranges, sizes and colours.

Logic modules (``jebik.game``) only read the numbers from here; nothing in this
file imports pygame, so it is safe to use from headless tests.
"""
from __future__ import annotations

from .paths import package_dir, resource_path

# ---------------------------------------------------------------- paths
# resource_path() also works inside a PyInstaller build (see jebik/paths.py)
PACKAGE_DIR = package_dir()
ASSETS_DIR = resource_path("assets")
FONT_DIR = ASSETS_DIR / "fonts"
AUDIO_DIR = ASSETS_DIR / "audio"
WORLDS_DIR = resource_path("worlds")      # <id>/levels/*.txt, <id>/audio/*.wav
FONT_BOLD = FONT_DIR / "MPLUSRounded1c-Bold.ttf"
FONT_REGULAR = FONT_DIR / "MPLUSRounded1c-Regular.ttf"

# ---------------------------------------------------------------- display
SCREEN_W, SCREEN_H = 1920, 1080
FPS = 60
MAX_DT = 1 / 20            # clamp long frames so physics never explodes
HUD_H = 110
TRANSITION_TIME = 0.28     # scene cross-fade, seconds

# Field layout. The spec's base cell is 64 px (the biggest 22x14 level gets it);
# small early levels get bigger cells so the pond does not look lost.
MAX_CELL = 80
FIELD_MARGIN_X = 200       # min free space left/right of the field
FIELD_MARGIN_Y = 30        # min free space above/below the field (below HUD)

# Supersampling factors for the drawn art.
SS_SPRITE = 4              # small cached sprites (frog, flies, icons)
SS_FIELD = 2               # the numpy water field (soft anyway)
SS_BACKDROP = 2            # full-screen backdrops (menu, shores)

# ---------------------------------------------------------------- frog
HOP_TIME = 0.15            # one-cell hop animation
SUPERJUMP_TIME = 0.30      # two-cell super jump
SUPERJUMP_COOLDOWN = 3.0
HOLD_REPEAT_DELAY = 0.05   # extra pause between hops while a key is held
TONGUE_RANGE = 2
TONGUE_RANGE_FIREFLY = 4
TONGUE_COOLDOWN = 0.5
TONGUE_EXTEND_SPEED = 26.0   # cells per second
TONGUE_RETRACT_SPEED = 20.0
TONGUE_HOLD = 0.04           # pause at full extension
FIREFLY_DURATION = 5.0
INVULN_TIME = 2.0
SPLASH_TIME = 0.75         # frog is under water before respawning
HIT_STUN_TIME = 0.35       # frog cannot act right after a snake bite
MAX_HEARTS = 3
START_HEARTS = 3

# ---------------------------------------------------------------- flies
FLY_MIN, FLY_MAX = 3, 5            # counted flies (fly/dragonfly) on the field
FLY_RESPAWN_DELAY = (1.2, 2.6)
FLY_SPEED = 2.4                    # cells per second
DRAGON_SPEED = 5.0
FLY_HOP_RANGE = (1, 3)             # cells per flight
DRAGON_HOP_RANGE = (2, 5)
FLY_REST_CHANCE = 0.55             # chance to sit down after a flight
FLY_REST_TIME = (1.0, 2.0)
FLY_SHORT_PAUSE = (0.15, 0.45)
FLY_WATER_CHANCE = 0.22            # chance a flight target is over water
DRAGON_CHANCE = 0.14               # chance a new counted fly is a dragonfly
GOLD_INTERVAL = (22.0, 34.0)       # seconds between golden flies
FIREFLY_INTERVAL = (30.0, 40.0)    # seconds between fireflies
SPECIAL_LIFETIME = 13.0            # golden/firefly leave after this long

FLY_VALUE = {"fly": 1, "dragon": 2, "gold": 0, "firefly": 0}

# ---------------------------------------------------------------- enemies / respawn
SAFE_RESPAWN_DIST = 3              # respawn tile must be this far from any enemy cell

# ---------------------------------------------------------------- tile hazards
UNSTABLE_WARN = 1.5                # flicker before an unstable tile vanishes
UNSTABLE_GONE = 4.0                # ... then it is gone this long
UNSTABLE_STABLE = 5.0              # "cycle" tiles stay solid this long between cycles
ROW_SLIDE_TIME = 0.35              # render slide of a moving row (logic shifts instantly)

# ---------------------------------------------------------------- bosses
BOSS_HP = 3
BOSS_WINDOW = 3.0                  # default vulnerability window, seconds
BOSS_HIT_FLASH = 0.6
BOSS_PILL_RESERVE = 64             # px kept above the field for the HUD boss pill

# ---------------------------------------------------------------- TOBI PIZDA
TOBI_DEFAULT_TIME = 120.0          # when a level has no tobi_time
TOBI_GOLD_BONUS = 10.0             # golden fly adds seconds
TOBI_WARN_TIME = 10.0              # HUD timer turns red below this
TOBI_RESTART_DELAY = 1.1           # "Ой!" before an automatic restart

# ---------------------------------------------------------------- scoring
SCORE_PER_FLY = 100
SCORE_PER_HEART = 200
SCORE_NO_DAMAGE = 500
SCORE_PER_SECOND_LEFT = 10         # TOBI PIZDA time bonus
RECORDS_KEEP = 10                  # runs kept per level per profile / rows shown
WIN_DELAY = 0.9                    # celebration before the win panel
LOSE_DELAY = 0.9

# ---------------------------------------------------------------- audio
MUSIC_TRACKS = ("A", "B", "C")
MUSIC_FILES = {"A": "music_a.wav", "B": "music_b.wav", "C": "music_c.wav"}
SFX_NAMES = ("jump", "tongue", "eat", "splash", "hit", "win", "lose",
             "superjump", "powerup", "click", "overeat", "full", "denied", "tick")
INTRO_FANFARE = "intro_fanfare.wav"
INTRO_CUSTOM = ("intro_custom.ogg", "intro_custom.wav")   # dropped in by the user: played instead

# ---------------------------------------------------------------- studio splash
STUDIO_TIME = 6.8                  # total, incl. fade in/out
STUDIO_FADE_IN = 0.6
STUDIO_FADE_OUT = 1.0
STUDIO_ZOOM = (1.0, 1.13)          # slow camera push-in
DEFAULT_SETTINGS = {
    "lang": "ua",
    "music_volume": 0.6,
    "sfx_volume": 0.8,
    "music_track": "B",
    "fullscreen": False,
    "show_grid": False,
    "touch": "auto",
}

# ---------------------------------------------------------------- touch
TOUCH_MODES = ("auto", "on", "off")   # auto = on-screen buttons after the first touch
TOUCH_SWIPE_MIN_DIST = 60          # logical px a finger must travel for a swipe
TOUCH_SWIPE_MAX_TIME = 0.35        # ... within this many seconds
TOUCH_TAP_MAX_DIST = 40            # a tap may wobble this far
TOUCH_TAP_MAX_TIME = 0.35
TOUCH_BUTTON_R = 60                # on-screen button radius (120 px, thumb-sized)
TOUCH_BUTTON_MARGIN = 36           # gap to the screen edges
TOUCH_BUTTON_ALPHA = 170           # semi-transparent over the field

# ---------------------------------------------------------------- colours
C_INK = (30, 80, 30)            # dark green outline / text on light buttons
C_INK_SOFT = (40, 90, 50)
C_BUTTON = (250, 250, 240)
C_BUTTON_HOT = (255, 215, 90)
C_BUTTON_SHADOW = (30, 90, 40)
C_BUTTON_DISABLED = (205, 210, 200)
C_TITLE = (120, 220, 90)
C_TITLE_OUTLINE = (30, 80, 30)
C_SUBTITLE_OUTLINE = (200, 80, 120)
C_WHITE = (255, 255, 255)
C_HUD_BG = (25, 45, 40)
C_HUD_LINE = (120, 220, 90)
C_HUD_TEXT = (235, 235, 235)
C_HUD_SUB = (170, 210, 170)
C_HUD_COUNTER = (255, 220, 110)
C_HUD_HINT = (200, 200, 170)
C_HUD_MUTED = (170, 190, 170)
C_HEART = (225, 50, 65)
C_HEART_EMPTY = (80, 80, 80)
C_PANEL = (250, 248, 236)
C_DIM = (10, 25, 30, 150)
C_STAR = (255, 205, 60)
C_STAR_EMPTY = (205, 200, 185)
C_RED_TEXT = (220, 60, 70)
C_GOOD = (120, 220, 90)
